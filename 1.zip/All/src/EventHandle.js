//9. event handling

import React, { useState } from 'react';

function EventHandle() {
    const [inputValue, setInputValue] = useState('');

    const handleChange = (event) => {
        setInputValue(event.target.value);
    };



    return (
        <div>
            <h1>{inputValue}</h1>
            <form>
                <input
                    type="text"
                    value={inputValue}
                    onChange={handleChange}
                    placeholder="Enter text"
                />
            </form>
        </div>
    );
}

export default EventHandle;
