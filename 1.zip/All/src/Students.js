//4 usestate in component like initialize {}

import React, { useState } from 'react';

export default function Students() {

    const initialdata = {
        name: "jay",
        age: '23'
    }

    const [list, setlist] = useState([initialdata]);


    function changeHandler() {
        setlist([{
            name: "rahul",
            age: '21'
        }]);

    }



    return (
        <div style={{ backgroundColor: "black", color: "white", padding: "20px" }}>
            <h1>{list.map((data, index) => {
                return (
                    <div key={index}>
                        <h2>{data.name}</h2>
                        <h4>{data.age}</h4>
                    </div>
                )
            })}</h1>
            <button onClick={changeHandler}>Change</button>
        </div>
    )
}
