// Weather.js
import React from 'react';
import { useState } from 'react';



function Weather(props) {
  const [temperature , setTemperature] = useState(0);
  return (
    <div>
      <h1>Weather App</h1>
     
      <p>City: {props.city}</p>
      <p>Country: {props.country}</p>

      <p>Temperature: {temperature}°C</p>
      <button onClick={() => setTemperature(25)}>Change Temperature</button>
    </div> 
  );
}

export default Weather;
