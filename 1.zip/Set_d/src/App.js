import React from 'react';
import FetchData from './Componet/FetchData';


function App() {
    
  
    return(
    <>
    <div className=' mt-5 container'>
        <FetchData/>
       
    </div>
    </>
    )
}

export default App;