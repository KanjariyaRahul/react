import './App.css';
import Controll from './Controll';


function App() {
  return (
   <>
    <Controll/>
    <hr/>
  
   </>
  );
}

export default App;
