import React, { useEffect, useState } from 'react';

export default function FetchData() {
    const [data, setMyData] = useState([]);
    const [error, setError] = useState(null);
    const [fetchTrigger, setFetchTrigger] = useState(false); 
    const [color, setColor] = useState("black")

    useEffect(() => {
        
        setColor(color === "green" ? "pink" : "green");
        if (fetchTrigger) {
            async function fetchData() {
               
                    const response = await fetch('https://swapi.py4e.com/api/films');
                    const data = await response.json();
                    setMyData(data.results);

                // fetch('https://swapi.py4e.com/api/films').then((respose) => {
                // return respose.json();
                // }).then((list) => {
                //     setMyData(list.results);
                // }).catch((error) => {
                //     alert(error)
                // })
            }

            fetchData(); 
        }
    }, [fetchTrigger]); 

    const handleFetchData = () => {
        setFetchTrigger(true); 
    };

    return (
        <div className='container mt-3 ' style={{ backgroundColor: `${color}`, padding: "20px" }}>
            {data.map((list) => (
                <div >
                    <h2>{list.title}</h2>
                    <p>{list.director}</p>
                </div>
            ))}
            {error && <p>Error: {error}</p>}
            <button onClick={handleFetchData} className='btn btn-success'>Fetch Api</button>
        </div>
    );
}