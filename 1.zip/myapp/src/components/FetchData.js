import React, { useState, useEffect } from 'react'

export default function FetchData() {

    const [data, setData] = useState([]);
    const [filter, setFilter] = useState([]);

    useEffect(() => {
        setFilter(data)
    }, [data])

    function clickHandler() {
        fetch('https://swapi.py4e.com/api/films').then((respose) => {
            return respose.json();
        }).then((data) => {
            setData(data.results);
        })
    }

    function filterData(title) {
        let dataFilter = data.filter((list) => {
            return list.title === title;
        })
        setFilter(dataFilter);
    }



    return (
        <div style={{ backgroundColor: "pink", height: "100vh" }}>
            {filter.map((list) => {
                return <div>
                    <h1>{list.title}</h1>
                    <p>{list.characters}</p>
                </div>

            })}
            <button onClick={clickHandler}>Fetch</button>
            <button onClick={() => filterData("A New Hope")}>filter Data</button>
        </div>
    )
}
