import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
    return (
        <nav className='flex justify-between items-center p-5 bg-amber-400'>
            <ul className='flex'>
                <li className='mx-2 hover:border-b hover:border-amber-900 duration-150'>
                    <Link to="/">Home</Link>
                </li>
                <li className='mx-2 hover:border-b hover:border-amber-900 duration-150'>
                    <Link to="/fetch">Fetch</Link>
                </li>
                {/* <li className='mx-2 hover:border-b hover:border-amber-900 duration-150'>
                    <Link to="input">Input</Link>
                </li> */}
            </ul>
        </nav>
    );
}
