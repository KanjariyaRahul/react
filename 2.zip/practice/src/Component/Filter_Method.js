import React, { useState, useEffect } from 'react';

const App = () => {
  // State to store the list of users
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetch data from the API
    fetch('https://jsonplaceholder.typicode.com/users')
      .then(response => response.json())
      .then(data => {
        // Once data is fetched, set the users state
        setUsers(data);
      })
      .catch(error => {
        console.error('Error fetching data: ', error);
      });
  }, []); // Empty dependency array to ensure useEffect runs only once on component mount

  // Filter out active users (for demonstration purpose, filtering based on user id)
  const activeUsers = users.filter(user => user.id % 2 === 0); // Filter based on user id

  return (
    <div>
      <h2>All Users:</h2>
      <ul>
        {users.map(user => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
      <h2>Active Users (Filtered by ID):</h2>
      <ul>
        {activeUsers.map(user => (
          <li key={user.id}>{user.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default App;
