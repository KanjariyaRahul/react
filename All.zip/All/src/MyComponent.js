//5. use conditional rendering at once

import React from 'react';

function MyComponent({ isLoggedIn }) {
    return (
        <div>
            {isLoggedIn ? (
                <p>Welcome, User!</p>
            ) : (
                <p>Please log in to continue</p>
            )}
        </div>
    );
}

export default MyComponent;
