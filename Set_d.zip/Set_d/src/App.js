import React, { useEffect, useState } from 'react'
import { Button } from "./Componet/Button";
import { Card } from "./Componet/Card";

function App() {

    const [data, setData] = useState([]);
    const [filter, setFilter] = useState([]);

    useEffect(() => {
      fetchData();
  }, []);

    function fetchData(){
        fetch('http://10.9.39.82:8000/api/setd').then((response)=>{
            return response.json();
        }).then((list)=>{
            setData(list.data);
        });
    }

    function filterData(names){
       if(names!="All"){
        let content = data.filter((list)=>{
            return list.domain ==  names
        })
        setFilter(content);
       }else{
        setFilter(data);
       }
        
    }

  console.log(filter);


    return(
    <>
    <div className=' mt-5 container'>
    <Button onclick={()=>filterData("All")}>All</Button>
    <Button  onclick={()=>filterData("Technology")}>Technology</Button>
    <Button  onclick={()=>filterData("E-commerce")}>E-commerce</Button>

    </div>
    <div  className="container mt-3">
        <Card data={filter}/>
    </div>
    </>
    )
}

export default App;