import React from 'react'

export const Button = (props) => {
  return (
    <button className='px-5 py-1  mx-2 btn btn-success rounded-lg text-lg text-white ' onClick={props.onclick}>{props.children}</button>
  )
}
