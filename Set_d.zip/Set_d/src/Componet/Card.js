
export const Card = ({data}) => {
  return (
    <>
           {data.map((list)=>{
               return <>
                <div className="container">
                <div className="card mb-3 col-sm-6 ">
                <div className="row ">
                    <div className="col-md-4 px-4 ">
                    <img src='http://10.9.39.82:8000/images/ElonMusk.jpg' className="img-fluid  mt-2" style={{ height: '70px'  , borderRadius : '50%' }} />
                    </div>
                    <div className="col-md-6">
                    <div className="card-body">
                    <h5 className="card-title">{list.name}</h5>
                        <p className="card-text">{list.domain}</p>
                    </div>
                    </div>
                </div>
                </div>

                </div>
                </>
           })}
           </>
  );
}