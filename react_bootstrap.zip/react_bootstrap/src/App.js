import './App.css';
import RecipeForm from './componet/RecipeForm';

function App() {
  return (
    <div className=" mx-5 mt-5">
       <RecipeForm/>
    </div>
  );
}

export default App;
