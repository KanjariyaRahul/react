import React, { useState,useEffect } from 'react';
import img from '../1.jpg';

const RecipeForm = () => {
  const [recipes, setRecipes] = useState([]);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [ingredients, setIngredients] = useState('');
  const [price, setPrice] = useState('');
  const [showInitialData, setShowInitialData] = useState(false);

  const handleSubmit = (event) => {
    event.preventDefault();
    setRecipes([...recipes, { title, category, ingredients, price }]);
    setTitle('');
    setCategory('');
    setIngredients('');
    setPrice('');
  };

 
  const data = [
    {
        "name": "Vegetable Stir Fry",
        "category": "Vegetarian",
        "ingredients": "A colorful and nutritious stir fry made with a variety of fresh vegetables sautéed in a flavorful sauce.",
        "price": 9.99,
        "image": "images/setb1.jpg"
      },
      {
        "name": "Caprese Salad",
        "category": "Salad",
        "ingredients": "A simple yet delicious salad made with fresh tomatoes, mozzarella cheese, basil leaves, and balsamic glaze.",
        "price": 7.49,
        "image": "images/setb2.jpg"
      },
      {
        "name": "Vegetable Curry",
        "category": "Vegetarian",
        "ingredients": "A fragrant and spicy curry dish made with an assortment of vegetables cooked in a rich coconut milk sauce.",
        "price": 11.99,
        "image": "images/setb3.jpg"
      },
      {
        "name": "Mushroom Risotto",
        "category": "Breakfast",
        "ingredients": "Creamy and comforting risotto made with arborio rice, mushrooms, onions, and Parmesan cheese.",
        "price": 13.99,
        "image": "images/setb1.jpg"
      },
      {
        "name": "Vegetable Lasagna",
        "category": "Vegetarian",
        "ingredients": "Layers of lasagna noodles, marinara sauce, assorted vegetables, and melted cheese, baked to perfection.",
        "price": 12.49,
        "image": "images/setb2.jpg"
      },
      {
        "name": "Greek Salad",
        "category": "Salad",
        "ingredients": "A refreshing salad made with crisp lettuce, tomatoes, cucumbers, olives, onions, and feta cheese, drizzled with olive oil and herbs.",
        "price": 8.99,
        "image": "images/setb3.jpg"
      },
      {
        "name": "Quinoa Stuffed Bell Peppers",
        "category": "Breakfast",
        "ingredients": "Bell peppers stuffed with a savory mixture of quinoa, black beans, corn, tomatoes, and spices, topped with melted cheese.",
        "price": 10.99,
        "image": "images/setb1.jpg"
      },
      {
        "name": "Vegetable Paella",
        "category": "Vegetarian",
        "ingredients": "A Spanish-inspired rice dish loaded with vegetables, saffron, and flavorful spices.",
        "price": 14.99,
        "image": "images/setb2.jpg"
      },
      {
        "name": "Eggplant Parmesan",
        "category": "Vegetarian",
        "ingredients": "Slices of eggplant coated in breadcrumbs, fried until crispy, layered with marinara sauce and melted mozzarella cheese.",
        "price": 11.49,
        "image": "images/setb3.jpg"
      },
      {
        "name": "Vegetable Pad Thai",
        "category": "Breakfast",
        "ingredients": "A Thai-inspired noodle dish made with stir-fried rice noodles, tofu, bean sprouts, peanuts, and a tangy sauce.",
        "price": 12.99,
        "image": "images/setb1.jpg"
      }
  ];

  const handleFilterRecipes = (category) => {
    
    const filteredRecipes = data.filter(recipe => recipe.category === category);
    setRecipes(filteredRecipes);
    if (category === 'all') {
      setRecipes(data);
    }

  };

  return (
    <div className='container d-flex'>
      <form onSubmit={handleSubmit} className="col-md-6">
        <h2>Add New Recipe</h2>
        <div className="form-group col-md-4 mt-2">
          <label>Recipe Title:</label>
          <input className='form-control' type="text" value={title} onChange={(event) => setTitle(event.target.value)} />
        </div>
        <div className="form-group col-md-4 mt-2">
          <label>Category:</label>
          <select className='form-control' value={category} onChange={(event) => setCategory(event.target.value)}>
            <option value="">Select a category</option>
            <option value="breakfast">Breakfast</option>
            <option value="lunch">Lunch</option>
            <option value="dinner">Dinner</option>
            <option value="dessert">Dessert</option>
          </select>
        </div>
        <div className="form-group col-md-4 mt-2">
          <label>Ingredients:</label>
          <textarea className='form-control' value={ingredients} onChange={(event) => setIngredients(event.target.value)} />
        </div>
        <div className="form-group col-md-4 mt-2">
          <label>Price:</label>
          <input type="number" className='form-control' value={price} onChange={(event) => setPrice(event.target.value)} />
        </div>
        <button type="submit" className='btn btn-success mt-3'>Add Recipe</button>
        
      </form>

      <div className="col-md-6">
        <h2>Recipes</h2>
        <div className="mt-3 ">
          <button onClick={() => handleFilterRecipes('Breakfast')} className='btn btn-info mt-3'> Breakfast</button>
          <button onClick={() => handleFilterRecipes('Vegetarian')} className='btn btn-info mt-3 mx-2'>lunch</button>
          <button onClick={() => handleFilterRecipes('Salad')} className='btn btn-info mt-3 mx-2'>Dinner</button>
          <button onClick={()=>handleFilterRecipes('all')} className='btn btn-info mt-3 mx-2'>All</button>
        </div>
        <div className='d-flex gap-3 mt-3 '>
          <ul className='d-flex gap-3 flex-wrap'>
            {showInitialData
              ? data.map((recipe, index) => (
                  <div key={index} className="card">
                    <div className="row">
                      <div className="col-md-4">
                        <img src={img} alt="Image" className="img-fluid" />
                      </div>
                      <div className="col-md-8">
                        <div className="card-body">
                          <h5 className="card-title">{recipe.name}</h5>
                          <p className="card-text">Category: {recipe.category}</p>
                          <p className="card-text">Ingredients: {recipe.ingredients}</p>
                          <p className="card-text">Price: {recipe.price}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              : recipes.map((recipe, index) => (
                  <div key={index} className="card">
                    <div className="row">
                      <div className="col-md-4">
                        <img src={img} alt="Image" className="img-fluid" />
                      </div>
                      <div className="col-md-8">
                        <div className="card-body">
                          <h5 className="card-title">{recipe.title}</h5>
                          <p className="card-text">Category: {recipe.category}</p>
                          <p className="card-text">Ingredients: {recipe.ingredients}</p>
                          <p className="card-text">Price: {recipe.price}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default RecipeForm;
